class Main {
  public static void main(String[] args) {
    ConfigurarGithub conf = new ConfigurarGithub();

    conf.banner = true;
    conf.cor = "Roxo";

    System.out.println("Possui banner? " +conf.banner);
    System.out.println("Cor do banner: " +conf.cor);

    conf.Apresentavel();

    conf.readme = true;
    System.out.println("Possui um bom readme? " +conf.readme);
    
    conf.Bom_readme();
  }
}