public class ConfigurarGithub{
  boolean banner;
  String cor;
  boolean readme;

  void Apresentavel(){
    if(banner==true){
      System.out.println("Está apresentável seu GitHub! " +this.banner);
    }else{
      System.out.println("Não está apresentável seu GitHub! " +this.banner);
    }
  }

  void Bom_readme(){
    if(this.readme == true){
      System.out.println("Ótimo! ");
    }else{
      System.out.println("Precisa realizar alterações em seu readme! ");
    }
  }
  

  
  
}