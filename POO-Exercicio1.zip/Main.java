class Main {
  public static void main(String[] args) {
    Jogador j1 = new Jogador();

    j1.nome = "Jubinha";
    j1.gols = 2;
    j1.assistencias = 1.5;

    j1.adicionar(2);
    System.out.println("A quantidade de gols marcados foi de:"+ j1.gols);
    
    j1.assisten(2.5);
    System.out.println("A quantidade de assistências fornecidas foi de:"+ j1.assistencias);
  }
}