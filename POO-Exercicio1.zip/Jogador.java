class Jogador{
  //Atributos(variáveis)
  String nome;
  int gols;
  double assistencias;

  void adicionar(int adicionarGol){
  gols += adicionarGol;
  }

  void assisten(double adicionarAssistencia){
  assistencias += adicionarAssistencia;
  }
}