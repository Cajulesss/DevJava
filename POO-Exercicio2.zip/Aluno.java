class Aluno{
  String nome;
}