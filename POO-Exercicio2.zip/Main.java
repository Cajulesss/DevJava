class Main {
  public static void main(String[] args) {
    Aluno alu = new Aluno();

  alu.nome = "Júlia";
  double [] notas = new double [3];
  notas[0] = 12;
  notas[1] = 14;
  notas[2] = 10;

  double media = notas[0]+notas[1]+notas[2];
  System.out.println("A média de Júlia é:"+media/3);

    if((notas[0]<notas[1])&&(notas[0]<notas[2])){
      System.out.println("A menor nota é:"+notas[0]);
    }else if((notas[1]<notas[0])&&(notas[1]<notas[2])){
      System.out.println("A menor nota é:"+notas[1]);
    }else{
      System.out.println("A menor nota é:"+notas[2]);
    }

    if((notas[0]>notas[1])&&(notas[0]>notas[2])){
      System.out.println("A maior nota é:"+notas[0]);
    }else if((notas[1]>notas[0])&&(notas[1]>notas[2])){
      System.out.println("A maior nota é:"+notas[1]);
    }else{
      System.out.println("A maior nota é:"+notas[2]);
    }
  }
}