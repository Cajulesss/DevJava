class Main {
  public static void main(String[] args) {
    Aluno alu = new Aluno();

  alu.nome = "Júlia";
  int [] notas = new int [3];
  notas[0] = 12;
  notas[1] = 14;
  notas[2] = 10;

  int media = notas[0]+notas[1]+notas[2];
  System.out.println("A média de Júlia é:"+media/3);

  //maior e menor nota
    System.out.println("Maior nota:"+notas[2]);
    System.out.println("Menor nota:"+notas[1]);
    
    
  }
}