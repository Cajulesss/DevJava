
class teste{
public static double teste (double pri,double segu){
    double som= pri+segu;
    return som;
  }
}