class Main {
//Criar método estático e que não retorna nada, para realizar uma soma e utilizando funções;(public,privade)
  
  public static void main(String[] args) {
    System.out.println("Está funcionando!");
    double mostrar = teste.teste (11.9,2.2);
    System.out.println("A soma vale:"+mostrar);
  }
}