class Main {
  public static void main(String[] args) {
    Computador c1 = new Computador();
    c1.cor = "Preto";
    c1.tela = 15;
    c1.webcam = true;
    c1.USB = true;
    c1.printar();

    c1.carregarCelular();
    
  }
}