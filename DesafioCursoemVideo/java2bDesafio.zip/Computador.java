public class Computador{
  String cor;
  int tela;
  boolean webcam;
  boolean dvd;
  boolean USB;

  void printar(){
    System.out.println("Cor do computador: " +this.cor);
    System.out.println("Tamanho da tela de exibição: " +this.tela);
    System.out.println("Você utiliza a entrada USB? " +this.USB);

    System.out.println("Webcam: " +this.webcam);
    if(this.webcam == true){
      System.out.println("Possui uma webcam para vídeo chamadas!");
    }else{
      System.out.println("Você não possui uma webcam");
    }
  }

  void carregarCelular(){
    if(this.USB == true){
    System.out.println("Você pode carregar seu celular em uma porta USB do seu computador!");
    }
  }
}